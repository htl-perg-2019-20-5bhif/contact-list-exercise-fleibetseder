﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{

    [Route("api/todo-items")]
    [ApiController]
    public class TodoItemsController : ControllerBase
    {
        // http://localhost:5000/api/todo-items url für Zugriff auf API wegen Route() oberhalb


        private static readonly List<TodoItem> items = new List<TodoItem> {
            new TodoItem { Description = "ABC", AssignedTo = "Me" } };

        [HttpGet]
        public IActionResult GetAllItems()
        {
            return Ok(items);
        }


        [HttpGet]
        [Route("{index}", Name = "GetSpecificItem")]
        public IActionResult GetItem(int index)
        {
            if (index >= 0 && index < items.Count)
            {
                return Ok(items[index]);
            }

            return BadRequest("Invalid index");
        }


        [HttpPost]
        public IActionResult AddItem([FromBody] TodoItem newItem)
        {
            items.Add(newItem);
            return CreatedAtRoute("GetSpecificItem", new { index = items.IndexOf(newItem) }, newItem);
        }

        [HttpPut]
        [Route("{index}")]
        public IActionResult UpdateItem(int index, [FromBody] TodoItem newItem)
        {
            if (index >= 0 && index < items.Count)
            {
                items[index] = newItem;
                return Ok();
            }

            return BadRequest("Invalid index");
        }


        [HttpDelete]
        [Route("{index}")]
        public IActionResult DeleteItem(int index)
        {
            if (index >= 0 && index < items.Count)
            {
                items.RemoveAt(index);
                return NoContent();
            }

            return BadRequest("Invalid index");
        }

    }


    public class TodoItem
    {
        [MinLength(5)]
        [MaxLength(50)]
        [Required]
        public string Description { get; set; }

        [MaxLength(50)]
        public string AssignedTo { get; set; }
    }

}
